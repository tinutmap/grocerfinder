module.exports = {
    "pluginOptions": {
        "apollo": {
            "lintGQL": true
        }
    }
}