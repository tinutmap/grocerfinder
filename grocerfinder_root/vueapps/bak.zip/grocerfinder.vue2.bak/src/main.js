// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import VueApollo from 'vue-apollo'
import ApolloClient from 'apollo-boost'

Vue.config.productionTip = false

/* eslint-disable no-new */
const apolloProvider = new VueApollo({
  defaultClient: new ApolloClient({
    uri: 'http://localhost/graphql/'
  })
})

Vue.use(VueApollo)

new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>',
  apolloProvider,
  render: h => h(App)
})
