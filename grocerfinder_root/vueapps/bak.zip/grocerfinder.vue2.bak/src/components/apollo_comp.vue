new Vue({
  apollo: {
    // Apollo specific options
  },
})

<template>
  <div class="apollo">
    <ul>
      <li v-for="item in allItems" :key="item.id">
        Name: {{ item.name }} , Category: {{ item.category.name }}
      </li>
    </ul>
  </div>
</template>

<script>
import gql from "graphql-tag";

export default {
  apollo: {
    // Simple query that will update the 'hello' vue property
    allItems: gql`
      query allItems {
        allItems {
          id
          name
          category {
            name
          }
        }
      }
    `,
  },
};

/*
fetch('http://localhost/graphql', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ query: 'query { allItems { name } }' })
})
*/
</script>
