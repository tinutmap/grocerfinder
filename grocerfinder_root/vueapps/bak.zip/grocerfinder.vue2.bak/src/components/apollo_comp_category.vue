new Vue({
  apollo: {
    // Apollo specific options
  },
})

<template>
  <div class="app">
    <div>
      <span>Category Name:</span><input type="text" v-model="name" />
      <button @click="create_category">Add</button>
    </div>
    <div>
      <table>
        <tr>
          <th></th>
          <th>ID</th>
          <th>Catergory Name</th>
          <th>Date Updated</th>
        </tr>
        <tr v-for="i in allCategories" :key="i.id">
          <td><!--v-checkbox :input-value="selected"--><!--/v-checkbox--></td>
          <td>{{ i.id }}</td>
          <td>{{ i.name }}</td>
          <td>{{ i.datetimeUpdated }}</td>
          <td>
            <button type="checkbox" @click="delete_category(i.id)">
              Delete
            </button>
          </td>
        </tr>
      </table>
    </div>
    <!--input type="button" @click="delete_category" value="Delete"-->
  </div>
</template>

<script>
import gql from "graphql-tag";

const CategoryMutationCreate = gql`
  mutation createCategory($name: String!) {
    createCategory(name: $name) {
      categories {
        id
        name
        datetimeUpdated
      }
    }
  }
`;

const allCategoriesQuery = gql`
  query allCategories {
    allCategories {
      id
      name
      datetimeUpdated
    }
  }
`;

const categoryMutationUpdate = gql`
  mutation updateCategory($id: ID!, $name: String!) {
    updateCategory(categoryId: $id, name: $name) {
      category {
        id
        name
        datetimeUpdated
      }
    }
  }
`;
const categoryMutationDelete = gql`
  mutation deleteCategory($id: ID!) {
    deleteCategory(id: $id) {
      ok
    }
  }
`;

export default {
  data() {
    return {
      name: "",
      selected: [],
      // Initialize your apollo data
    };
  },
  apollo: {
    allCategories: allCategoriesQuery,
  },
  methods: {
    async create_category() {
      const name = this.name;
      // Call to the graphql mutation
      const data = await this.$apollo.mutate({
        // Query
        mutation: CategoryMutationCreate,
        // Parameters
        variables: {
          name: name,
        },
        refetchQueries: [
          {
            query: allCategoriesQuery,
          },
        ],
        // This way below does not make the latest update category to top per query design in django
        // update: (store, { data: { createCategory } }) => {
        // Add to All Category list
        //  const data = store.readQuery({ query: allCategoriesQuery })
        //  data.allCategories.push(createCategory.categories)
        // store.writeQuery({ query: allCategoriesQuery, data })
        // }
      });
      var t = data.data.createCategory.categories;
      console.log("Added: ", t);
      this.name = "";
      this.description = "";
    },
    query_category() {
      const data = this.$apollo.query({
        // Query
        query: allCategoriesQuery,
      });
      return data;
    },
    update_category(id, name, datetimeUpdated) {
      console.log(`Update category: # ${id}`);
      this.$apollo.mutate({
        mutation: categoryMutationUpdate,
        variables: {
          id: id,
          name: name,
        },
      });
    },
    async delete_category(id) {
      // console.log(`Delete category: # ${id}`)
      await this.$apollo.mutate({
        mutation: categoryMutationDelete,
        variables: {
          id: id,
        },
        refetchQueries: [
          {
            query: allCategoriesQuery,
          },
        ],
      });
      // this.allCategories = this.query_category()
      // location.reload()
      // var t = data.data.deleteCategory.ok
      console.log(`Delete: # ${id}`);
    },
  },
};
</script>
