<template>
  <div>
    <p>Aldi Main</p>
    <ul>
      <li v-for="name in directory" :key="name.id">
        {{ name }}
      </li>
    </ul>
    {{directory}}
    {{ name_apollo }}
  </div>
</template>

<script>
/* Using Axios
import axios from 'axios'
export default {
  name: 'aldiMain',
  data () {
    return {
      directory: []
    }
  },
  async mounted () {
    try {
      var result = await axios({
        method: 'POST',
        url: 'http://localhost/graphql/',
        data: {
          query: `
          {
            allItems {
              id
              name
              category {
                id
                name
              }
            }
          }
          `
        }
      })
      this.directory = result.data.data.allItems
    } catch (error) {
      console.error(error)
    }
  }
}
*/
import gpl from 'graphql-tag'

export default {
  apollo: {
    name_apollo: gpl` query {
      allItems {
        id
        name
        category {
          id
          name
         }
      }
    }`
  }
}

</script>

<style scoped>
</style>
