<template>
  <div id="app">
    <img src="./assets/logo.png" />
    <!--router-view -->
    <!--aldiMain/-->
    <!--apolloComp/-->
    <apolloCompCategory/>
  </div>
</template>

<script>
import aldiMain from './components/aldi_main'
import apolloComp from './components/apollo_comp'
import apolloCompCategory from './components/apollo_comp_category'

export default {
  name: 'App',
  components: {
    aldiMain,
    apolloComp,
    apolloCompCategory
  }
}
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
